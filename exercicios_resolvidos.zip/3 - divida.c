#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    float divida, aplic, juros, crescdiv;
    int i;

    printf("Digite o valor da divida:\n");
    scanf("%f", &divida);
    printf("Digite o valor da aplicacao:\n");
    scanf("%f", &aplic);
    printf("Digite o valor dos juros mensais:\n");
    scanf("%f", &juros);
    printf("Digite a taxa do crescimento da divida:\n");
    scanf("%f", &crescdiv);

    for(i=0; aplic<=divida; i++)
    {
        divida=divida*(1+(crescdiv/100.0));
        aplic=aplic*(1+(juros/100.0));
    }

    printf("Tempo para quitar a divida: %d meses\n", i);
    printf("======================================\n");
    return 0;
}

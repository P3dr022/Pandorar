#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    char c;
    float P,V,R,I;
    int opcao=1;
    while (opcao != 0)
    {
        printf("MULTIMETRO DIGITAL\n");
        printf("DIGITE:\n");
        printf("(1) para calcular tensao\n");
        printf("(2) para calcular resistencia\n");
        printf("(3) para calcular corrente\n");
        printf("(4) para calcular potencia\n");
        printf("(0) para sair \n");
        printf("OPCAO:");
        scanf("%d",&opcao);
        switch (opcao)
        {
        case 1:
            printf("digite a resistencia:");
            scanf("%f",&R);
            printf("digite a corrente:");
            scanf("%f",&I);
            V = R * I;
            printf("O valor da tensao eh %f volts\n",V);
            break;
        case 2:
            printf("digite a corrente:");
            scanf("%f",&I);
            printf("digite a tensao:");
            scanf("%f",&V);
            R = V / I;
            printf("O valor da resistencia eh %f ohms\n",R);
            break;
        case 3:
            printf("digite a resistencia:");
            scanf("%f",&R);
            printf("digite a tensao:");
            scanf("%f",&V);
            I = V / R;
            printf("O valor da corrente eh %f amperes\n",I);
            break;
        case 4:
            printf("digite a tensao:");
            scanf("%f",&V);
            printf("digite a corrente:");
            scanf("%f",&I);
            P = V * I;
            printf("O valor da potencia eh %f watts\n",P);
            break;
        case 0:
            break;
        default:
            printf("opcao invalida");
            break;
        }
    }
    return 0;
}

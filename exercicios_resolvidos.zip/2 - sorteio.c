#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char *argv[])
{
    srand (time(NULL));
    int numero = rand()%11;
    int n,i=1;

    while(numero != n)
    {
        printf("tente adivinhar um numero de 1 a 10\ndigite um numero:");
        scanf("%d",&n);

        if (numero == n)
        {
            printf("parabens voce conseguiu em %d tentativas!\n",i);
        }
        else
        {
            printf("voce errou, tente novamente\n");
            if (n < numero)
            {
                printf("o numero eh maior\n");
            }
            else
            {
                printf("o numero eh menor\n");
            }
        }
        i++;
    }
    return 0;
}

#include <stdio.h>
#include <stdlib.h>

void reajuste(float salario,int tempo_servico)
{
    if(salario>2000 && tempo_servico==0)
    {
        printf("Nao tem direito a reajuste.\n");
        return 0;
    }
    if(salario<=500)
    {
        salario = salario*1.25;
    }
    else if(salario<=1000)
    {
        salario = salario*1.20;
    }
    else if(salario<=1500)
    {
        salario = salario*1.15;
    }
    else
    {
        salario = salario*1.10;
    }
    printf("Salario com reajuste: %.2f\n",salario);

    if(tempo_servico<1)
    {
        salario = salario+0;
    }
    else if(tempo_servico<=3)
    {
        salario = salario+100;
    }
    else if(tempo_servico<=6)
    {
        salario = salario+200;
    }
    else if(tempo_servico<=10)
    {
        salario = salario+300;
    }
    else
    {
        salario = salario+500;
    }
    printf("Salario com reajuste e bonus: %.2f\n",salario);

}


int main(int argc, char *argv[])
{
    float salario;
    int tempo_servico;

    printf("Digite seu salario:  ");
    scanf("%f",&salario);
    printf("Digite seu tempo de servico em anos:  ");
    scanf("%d",&tempo_servico);
    reajuste(salario,tempo_servico);

    return 0;
}

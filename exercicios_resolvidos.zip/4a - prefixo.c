#include <stdio.h>
#include <stdlib.h>

float calcula_taxa(int ddd)
{
    float taxa;
    switch(ddd)
    {
    case 54:
    case 598:
    case 595:
    case 56:
        taxa = 1.90;
        break;
    case 49:
    case 33:
    case 44:
        taxa = 2.00;
        break;
    case 1:
        taxa = 2.10;
        break;
    default:
        taxa = 2.30;
        break;
    }
    return taxa;
}


float calcula_custo(int minutos, float taxa)
{
    float custo;
    if (minutos>5)
    {
        custo = (5*taxa)+(((minutos-5)*taxa)*0.95);
    }
    else
    {
        custo = taxa *minutos;
    }
    return custo;
}


int main(int argc, char *argv[])
{
    int minutos,ddd, sn;
    float taxa, custo;

    while (sn != 1)
    {
        printf("calculo de custos e taxas de licacoes do brasil para o internacional\n");
        printf("digite o ddd: ");
        scanf("%d",&ddd);
        printf("digite a quantidade de minutos: ");
        scanf("%d",&minutos);
        taxa = calcula_taxa(ddd);
        custo = calcula_custo(minutos, taxa);
        printf("taxa = %f\nminutos = %d\ncusto final: %f\n",taxa,minutos,custo);
        printf("deseja encerrar o programa(digite 1 para parar)?");
        scanf("%d",&sn);
    }

    return 0;
}

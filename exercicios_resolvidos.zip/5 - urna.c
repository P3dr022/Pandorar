#include<stdio.h>
#include<stdlib.h>

//imprime de maneira ordenada decrescente
//vejo qual é o maior de todos e depois o segundo maior
void estatisticasDecres(int fulano, int cicrano, int beltrano)
{
    system("clear"); //system("cls") no windows
    int primeiro = fulano, segundo = cicrano, terceiro = beltrano;
    float total;

    if(fulano > cicrano && fulano > beltrano)
    {
        primeiro = fulano;

        if(cicrano > beltrano)
        {
            segundo = cicrano;
            terceiro = beltrano;
        }
        else
        {
            segundo = beltrano;
            terceiro = cicrano;
        }

    }
    else if(cicrano > fulano && cicrano > beltrano)
    {
        primeiro = cicrano;

        if(fulano > beltrano)
        {
            segundo = fulano;
            terceiro = beltrano;
        }
        else
        {
            segundo = beltrano;
            terceiro = fulano;
        }

    }
    else if(beltrano > cicrano && beltrano > fulano)
    {
        primeiro = beltrano;

        if(cicrano > fulano)
        {
            segundo = cicrano;
            terceiro = fulano;
        }
        else
        {
            segundo = fulano;
            terceiro = cicrano;
        }

    }

    total = fulano + cicrano +  beltrano;
    system("clear");
    printf("\t\tEstatísticas\n");
    printf("%d votos para candidato1, %d votos para candidato2, %d votos para candidato3\n", primeiro, segundo, terceiro);
    printf("%.2f%% votos para candidato1, %.2f%% votos para candidato2,%.2f%% votos para candidato3\n", (primeiro/total)*100, (segundo/total)*100, (terceiro/total)*100);

}

//verifica quem ganhou. basta saber qual variavel tem o valor maior
void computaVencedor(int a, int b, int c)
{
    if(a > b && a > c)
    {
        printf("Candidato Fulano Vencedor!\n");

    }
    else if(b > a && b > c)
    {
        printf("Candidato Cicrano Vencedor!\n");

    }
    else if(c > a && c > b)
    {
        printf("Candidato Beltrano Vencedor!\n");
    }
    else
    {
        printf("Empate!!\n");
    }
}

//codigo principal
int main()
{
    int fulano = 0, cicrano = 0, beltrano = 0, opcao = 0, nulo = 0;
    char confirma;
    float total;

    //faca enquanto nao digitar 12345
    do
    {
        printf("\t\tVOTACAO\n");
        printf("DIGITE:\n(1) para FULANO\n(2) para CICRANO\n(3) para BELTRANO\n");
        printf("OPCAO:");
        scanf("%d", &opcao);

        switch(opcao)
        {
        case 1:
            printf("Votando em Fulano. Confirma (s/n)?");
            getc(stdin);
            scanf("%c", &confirma);
            if(confirma == 's')
            {
                system("clear"); //system("cls") no windows
                printf("\t\tCONFIRMADO!!!!!\n\n");
                fulano++;
            }
            break;
        case 2:
            printf("Votando em Cicrano. Confirma (s/n)?");
            getc(stdin);
            scanf("%c", &confirma);
            if(confirma == 's')
            {
                system("clear"); //system("cls") no windows
                printf("\t\tCONFIRMADO!!!!!\n\n");
                cicrano++;
            }
            break;
        case 3:
            printf("Votando em Beltrano. Confirma (s/n)?");
            getc(stdin);
            scanf("%c", &confirma);
            if(confirma == 's')
            {
                system("clear"); //system("cls") no windows
                printf("\t\tCONFIRMADO!!!!!\n\n");
                beltrano++;
            }
            break;
        default:
            if(opcao != 12345)
            {
                printf("Voto Nulo\n");
                nulo++;
            }
        }
    }
    while(opcao != 12345); //meu codigo secreto e 12345

    total = fulano + cicrano +  beltrano;

    system("clear"); //system("cls") no windows
    printf("\t\tEstatísticas\n");
    printf("%d votos para Fulano, %d votos para cicrano, %d votos para beltrano\n", fulano, cicrano, beltrano);
    printf("%.2f%% votos para Fulano, %.2f%% votos para cicrano,%.2f%% votos para beltrano\n", (fulano/total)*100, (cicrano/total)*100, (beltrano/total)*100);

    //estatisticasDecres(fulano, cicrano, beltrano);
    computaVencedor(fulano, cicrano, beltrano);
    printf("Votos nulos: %d\n", nulo);

    return 0;
}


